#' A function to build a classifier for RNA structure change
#'
#' This function builds a random forest classifier for RNA structure change in SHAPE data
#' @title classifyRNA
#' @aliases classifyRNA
#' @keywords classifier RNA structure change random forest
#' @usage classifyRNA(data=NULL, classes=1, cutoff=NULL)
#' @param data Optional data to build the classifier. Default is pre-loaded data.
#' @param classes An optional number indicating which class style to use. Only used when data is not supplied. Default is 1.
#' @param cutoff An optional vector of length equal to number of classes. The winning class for an observation is the one with the maximum ratio of proportion of votes to cutoff. Default is 1/k where k is the number of classes (i.e., majority vote wins).
#' @export
#' @import randomForest
#' @details This function builds a random forest classifier for RNA structure change using the randomForest package.
#' @return A classifyRNA object, based on randomForest object (see randomForest package)
#' \describe{
#'  \item{call}{The original call to randomForest}
#'  \item{type}{One of regression, classification, or unsupervised.}
#'  \item{predicted}{The predicted values of the input data based on out-of-bag samples.}
#'  \item{importance}{A matrix with nclass + 2 columns. The first nclass columns are the class-specific measures computed as mean descrease in accuracy. The nclass + 1st column is the mean descrease in accuracy over all classes. The last column is the mean decrease in Gini index.}
#'  \item{importanceSD}{The standard errors of the permutation-based importance measure. A p by nclass + 1 matrix corresponding to the first nclass + 1 columns of the importance matrix.}
#'  \item{ntree}{Number of trees grown.}
#'  \item{mtry}{Number of predictors sampled for spliting at each node.}
#'  \item{forest}{A list that contains the entire forest}
#'  \item{err.rate}{Vector error rates of the prediction on the input data, the i-th element being the (OOB) error rate for all trees up to the i-th.}
#'  \item{confusion}{The confusion matrix of the prediction (based on OOB data).}
#'  \item{votes}{A matrix with one row for each input data point and one column for each class, giving the fraction or number of (OOB) votes from the random forest.}
#'  \item{oob.times}{Number of times cases are out-of-bag (and thus used in computing OOB error estimate)}
#'  \item{proximity}{A matrix of proximity measures among the input (based on the frequency that pairs of data points are in the same terminal nodes).}
#' }
#' @note Organization of the data file: header=TRUE, tab-delimited .txt file
#' \itemize{
#'  \item{"column 1"}{ class label} 
#'  \item{"column 2"}{ magnitude change} 
#'  \item{"column 3"}{ pattern change} 
#'  \item{"column 4"}{ change distance} 
#'  \item{"column 5"}{ time warping} 
#'  \item{"column 6"}{ trace difference} 
#'  \item{"column 7"}{ rna length} 
#' }
#' Options for classes: 
#' \itemize{
#'  \item{"1"}{ none v. local/global}
#'  \item{"2"}{ global v. none/local} 
#'  \item{"3"}{ local v. global}
#' }
#' The default data has been gathered from the RNA Mapping Database mutate and map experiments.
#' @author Chanin Tolson
#' @references A. Liaw and M. Wiener (2002). Classification and Regression by randomForest. R News 2(3), 18--22 (randomForest package) \cr\cr
#' \href{http://rmdb.stanford.edu/}{RNA Mapping Database}
#' @seealso  \code{\link{getFeatures}}
#' @examples
#' #build classifier
#' rf = classifyRNA(classes=1)
#' #get confusion matrix
#' rf$confusion
#' 
classifyRNA = function(data=NULL, classes=1, cutoff=NULL){
  
  #set optional paramater classes
  if(missing(classes)){
    classes = 1
  } else {
    if(!(classes %in% c(1,2,3))){
      warning("classes set to default.")
      classes = 1
    }
    classes = classes
  }
  
  #set optional paramater data
  if(missing(data)){
    data = classSNitch::classify_default
    responses = data[,classes]
    input = data[,4:9]
  } else {
    data = data
    if(ncol(data) != 7){
      stop("Incorrect data file format.")
    }
    responses = data[,1]
    input = data[,2:7]
  }
  
  #set optional paramater cutoff
  if(!missing(cutoff)){
    if(length(cutoff)!=length(unique(responses[-which(is.na(responses))]))){
      warning("cutoff set to default.")
      cutoff = rep(1/length(unique(responses[-which(is.na(responses))])), length(unique(responses[-which(is.na(responses))])))
    }
    cutoff = cutoff
  } else {
    cutoff = rep(1/length(unique(responses[-which(is.na(responses))])), length(unique(responses[-which(is.na(responses))])))
  }

  #get features
  input = as.data.frame(cbind(responses, input))
  rownames(input) = rownames(data)
  colnames(input) = c("class", "mag", "pat", "loc", "tw", "tc", "len") 
  if(sum(is.na(input[,1]), na.rm=T)>0){
    input = input[-which(is.na(input[,1]),arr.ind=T),]
  }
  input[,1] = factor(as.numeric(input[,1]==1))
  
  #random forest classification
  rf = randomForest(class~., data=input, importance=TRUE, proximity=TRUE, ntree=5001, cutoff=cutoff)
  
  #convert to a classifyRNA object
  cr = structure(rf, class = "classifyRNA")
  
  #return classifyRNA object
  return(cr)
}

