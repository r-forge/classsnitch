#' A dataset of class labels and change features from SHAPE-traces in the RMDB
#' @title classify_default
#' @name classify_default
#' @aliases classify_default
#' @docType data
#' @export classify_default
#'
#' @keywords datasets
#'
#' @references \href{http://rmdb.stanford.edu/}{RNA Mapping Database}
#'
NULL